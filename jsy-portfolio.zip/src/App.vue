<template>
	<div>
		<PageHeader/>
		<PageMain/>
	</div>
</template>

<script setup>
import PageHeader from '@/components/PageHeader'
import PageMain from '@/pages/PageMain'

</script>

<style>
*{
	margin:0; 
	padding:0; 
	box-sizing: border-box;
}
ul, li, ol{
	list-style: none;
}
a{
	text-decoration: none;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
</style>
