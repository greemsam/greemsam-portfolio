<template>
	<div class="page-main">
		<p>문장문장문장문장문장</p>
		<ul>
			<li></li>
			<li></li>
		</ul>
	</div>
</template>

<script setup>

</script>

<style lang="scss" scoped>
	.page-main{
		ul{
			display:flex;
			justify-content:space-between;
			li{
				width:400px; //1000*560 
				height:224px;
				background:#ddd;
				margin:0 auto;
			}
		}
	}
</style>