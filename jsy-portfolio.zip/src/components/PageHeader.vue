<template>
	<header>
		<h1>Greem Sam</h1>
		<ul>
			<li>List</li>
			<li>List</li>
			<li>List</li>
			<li>List</li>
		</ul>
	</header>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>